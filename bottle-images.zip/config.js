const config = {
  user: 'AdsInc',
  pass: 'Ads123',
  dbUri: 'mongodb://AdsInc:Ads123@ds135800.mlab.com:35800/offer-database',
  jwtSecret: '@adsInc123',
  cloudinaryUploadUrl: 'https://api.cloudinary.com/v1_1/bottleimages/image/upload',
  cloudinaryUploadPreset: 'bottleimage',
  accounts: {
    mike: 'Basic YmFsbGluZ2NvcnBAZ21haWwuY29tOlh3dmNqS1JEa0IlNA==',
    ralph: '',
    jrs: '',
    jarah: '',
    derek: ''
  }
}


module.exports = config;
