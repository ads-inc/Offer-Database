import React, {Component} from 'react'
import OfferIds from './OfferIds'


export default class OfferIdsContainer extends Component {
  render() {
    return (
      <OfferIds />
    )
  }
}
