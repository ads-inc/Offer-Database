import React from 'react';

const DefaultHome = () => {

}

export default DefaultHome;
