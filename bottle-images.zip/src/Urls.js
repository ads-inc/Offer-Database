const Urls = [
 {
    name : 'skin',
    url  : '/api/skin'
  },
 {
    name : 'ed',
    url  : '/api/ed'
  },
 {
    name : 'diet',
    url  : '/api/diet'
  },
 {
    name : 'muscle',
    url  : '/api/muscle'
  },
]

export default Urls;
