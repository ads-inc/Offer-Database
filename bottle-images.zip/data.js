const data = [
  { id: 1, author: 'Bryan', text: 'wow this is cool'},
  { id: 2, author: 'Me', text: 'yee!'}
]

module.exports = data;
